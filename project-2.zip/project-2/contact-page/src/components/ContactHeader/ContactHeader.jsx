import styles from "./ContactHeader.module.css";

function ContactHeader() {
  return (
    <div className={`${styles.contact_section}`}>
      <h1>CONTACT US</h1>
      <p>
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Voluptatibus
        doloribus reprehenderit animi sint iusto quia, nostrum aut, odit non
        tempora quis consequuntur veniam saepe magni rerum nobis omnis molestias
        sunt!
      </p>
    </div>
  );
}

export default ContactHeader;
