import Button from "../Button/Button";
import styles from "./Contact.module.css";
import { MdMessage } from "react-icons/md";
import { FaPhoneAlt } from "react-icons/fa";
import { MdOutlineMail } from "react-icons/md";

const ContactForm = () => {
  return (
    <section className={styles.container}>
      <div className={styles.form_contact}>
        <div className={styles.top_btn}>
          <Button text="VIA SUPPRT CHAT" icon={<MdMessage fontSize="24px" />} />
          <Button text="VIA CALL" icon={<FaPhoneAlt fontSize="24px" />} />
        </div>
        <Button
          isOutLine={true}
          text="VIA EMAIL FORM"
          icon={<MdOutlineMail fontSize="24px" />}
        />

        <form>
          <div className={styles.form_controller}>
            <label htmlFor="Name">Name</label>
            <input type="text" name="name" />
          </div>
          <div className={styles.form_controller}>
            <label htmlFor="email">Email</label>
            <input type="email" name="email" />
          </div>
          <div className={styles.form_controller}>
            <label htmlFor="text">Text</label>
            <textarea name="text" rows="6" />
          </div>
        </form>
        <div className={styles.submit_btn}>
          <Button text="SUBMIT" />
        </div>
      </div>
      <div className={styles.image}>
        <img src="/images/image.avif" alt="image" />
      </div>
    </section>
  );
};

export default ContactForm;
